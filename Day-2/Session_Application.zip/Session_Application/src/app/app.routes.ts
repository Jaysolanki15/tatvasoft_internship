import { Routes } from '@angular/router';
import { StudentFormComponent } from './components/student-form/student-form.component';

export const routes: Routes = [
    {path:'', component:StudentFormComponent}
];
