﻿namespace Mission.Entity.Models.CommonModels
{
    public class UploadFileRequestModel
    {
        public string ModuleName { get; set; }
    }
}
