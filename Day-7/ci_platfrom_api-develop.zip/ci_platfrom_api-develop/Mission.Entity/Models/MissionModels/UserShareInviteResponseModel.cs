﻿namespace Mission.Entity.Models.MissionModels
{
    public class UserShareInviteResponseModel
    {
        public int Id { get; set; }

        public string UserFullName { get; set; }

        public string EmailAddress { get; set; }
    }
}
