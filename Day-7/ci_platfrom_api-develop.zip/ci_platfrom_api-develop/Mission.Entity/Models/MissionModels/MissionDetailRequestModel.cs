﻿namespace Mission.Entity.Models.MissionModels
{
    public class MissionDetailRequestModel
    {
        public int UserId { get; set; }
        public string SortestValue { get; set; }
        public int MissionId { get; set; }
    }
}
