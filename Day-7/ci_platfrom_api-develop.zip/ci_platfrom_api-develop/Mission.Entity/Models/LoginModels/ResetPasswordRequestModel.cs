﻿namespace Mission.Entity.Models.LoginModels
{
    public class ResetPasswordRequestModel
    {
        public string Uid { get; set; }

        public string Password { get; set; }
    }
}
