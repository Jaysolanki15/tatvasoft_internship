﻿namespace Mission.Entity.Models.MissionThemeModels
{
    public class AddMissionThemeRequestModel
    {
        public string ThemeName { get; set; }

        public string Status { get; set; }
    }
}
