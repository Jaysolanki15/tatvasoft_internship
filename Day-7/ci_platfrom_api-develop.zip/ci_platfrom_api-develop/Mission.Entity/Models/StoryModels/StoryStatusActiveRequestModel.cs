﻿namespace Mission.Entity.Models.StoryModels
{
    public class StoryStatusActiveRequestModel
    {
        public int Id { get; set; }

        public bool IsActive { get; set; }
    }
}
