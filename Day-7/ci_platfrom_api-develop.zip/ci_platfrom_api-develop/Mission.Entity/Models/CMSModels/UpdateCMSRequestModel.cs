﻿namespace Mission.Entity.Models.CMSModels
{
    public class UpdateCMSRequestModel : AddCMSRequestModel
    {
        public int Id { get; set; }
    }
}
