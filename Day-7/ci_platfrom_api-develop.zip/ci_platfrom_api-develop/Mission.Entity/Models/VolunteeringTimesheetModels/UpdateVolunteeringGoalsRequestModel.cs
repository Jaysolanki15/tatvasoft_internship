﻿namespace Mission.Entity.Models.VolunteeringTimesheetModels
{
    public class UpdateVolunteeringGoalsRequestModel : AddVolunteeringGoalsRequestModel
    {
        public int Id { get; set; }
    }
}
